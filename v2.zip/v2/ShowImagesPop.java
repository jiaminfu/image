package com.didi365.didi.client.common.views;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.didi365.didi.client.R;
import com.didi365.didi.client.appmode.my._beans.ImageBean;
import com.didi365.didi.client.appmode.my.my.GarageOperation;
import com.didi365.didi.client.appmode.sendgift._interfaces.GiftNetListener;
import com.didi365.didi.client.base.BaseActivity;
import com.didi365.didi.client.common.CommonCache;
import com.didi365.didi.client.common.RxBus;
import com.didi365.didi.client.common.imgloader.ImageLoad;
import com.ihengtu.xmpp.core.helper.XmppFileHelper;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author jiamin_fu
 * @Description: TODO(多张大图图片预览)
 * @date 2015年8月1日 上午10:12:00
 */
public class ShowImagesPop extends BaseActivity {
    private static final String TAG = "ShowImagesPop";
    private ViewPager picViewpager;
    private TextView popTitleTv, deleteTv;
    private ImageView backIv;
    private PicPagerAdapter popAdapter;
    private List<ImageView> popImageViews;
    private List<ImageBean> listString;
    private ArrayList<String> picPathList;
    private int picPosition;
    private int postionParent;// 订单评价页面用到
    private int picInt;
    private int isLoad;//是不是本地图片, 0网络，1本地
    private boolean isDelete; // 是否可以删除
    private boolean isCap; // 是否为队长
    private BottomPopupWindow mPopupWindow;
    private ImageView imageView;
    private Boolean popTitleTv_Show = true;
    private boolean delete = false;
    private GarageOperation Goperation;
    public int uploadNum = 0; // 已经上传的数量
    public int uploadNumed = 0; // 打算上传的数量
    private String uploadPath = "";// 图片于服务器上的url
    public String lengthPath = ""; // 相册图片一起上传
    private String tid; // 车队id

    @Override
    public boolean debug() {
        return false;
    }

    /**
     * 删除相册
     *
     * @param id
     */
    private void deletePhoto(String id) {
        Goperation.deletePhoto(new GiftNetListener<String>() {
            @Override
            public void requestSuccess(String s) {
                NormalToast.showToast(ShowImagesPop.this, s, Toast.LENGTH_SHORT);
                delete = true;
                RxBus.getRxBus().post("isnotice",true);
                deletePic();
            }

            @Override
            public void requestFail(String s) {
                NormalToast.showToast(ShowImagesPop.this, s, Toast.LENGTH_SHORT);
            }
        }, id);
    }

    @Override
    public void initView() {
        setContentView(R.layout.pop_homepage_goods_pic);
        picViewpager = (ViewPager) findViewById(R.id.shop_detail_pic_vp);
        popTitleTv = (TextView) findViewById(R.id.shop_detail_textview);
        deleteTv = (TextView) findViewById(R.id.shop_detail_delete);
        backIv = (ImageView) findViewById(R.id.shop_detail_back);

        popAdapter = new PicPagerAdapter();
    }

    @Override
    public void initData() {
        Goperation = new GarageOperation(this);
        picPathList = new ArrayList<>();
        popImageViews = new ArrayList<>();
        listString = (List<ImageBean>) getIntent().getSerializableExtra("beanList");
        picPathList = getIntent().getStringArrayListExtra("picList");
        picPosition = getIntent().getIntExtra("picPosition", 0);
        postionParent = getIntent().getIntExtra("postionParent", 0);
        isLoad = getIntent().getIntExtra("isLoad", 0);
        isDelete = getIntent().getBooleanExtra("isDelete", false);
        isCap = getIntent().getBooleanExtra("isCap", false);
        popTitleTv_Show = getIntent().getBooleanExtra("tv_show", true);
        tid = getIntent().getStringExtra("tid");
        if (popTitleTv_Show) {
            popTitleTv.setVisibility(View.VISIBLE);
        } else {
            popTitleTv.setVisibility(View.GONE);
        }
        picInt = R.drawable.morengoods_shouye;

        if (isDelete) {
            deleteTv.setVisibility(View.GONE);
        } else {
            deleteTv.setVisibility(View.GONE);
        }
        if (picPathList.size() == 0) {
            picInt = R.drawable.morengoods_shouye;
            final TouchImageView iv = new TouchImageView(
                    getApplicationContext());
            iv.setImageResource(picInt);
            popImageViews.add(iv);
        }
        for (int i = 0; i < picPathList.size(); i++) {
            final TouchImageView iv = new TouchImageView(
                    getApplicationContext());
            iv.setImageResource(picInt);
            popImageViews.add(iv);
            /*if(isLoad == 0) {
                ImageLoad.getAgainImage(ShowImagesPop.this, picPathList.get(i), iv,
					R.drawable.smdd_place_350, R.drawable.smdd_place_350);
			} else {
				AsyncLocalImageLoader.getInstance().addTask(picPathList.get(i), iv);
			}*/
            ImageLoad.getAgainImage(ShowImagesPop.this, picPathList.get(i), iv,
                    R.drawable.smdd_place_350, R.drawable.smdd_place_350);
        }
        popAdapter = new PicPagerAdapter();
        picViewpager.setAdapter(popAdapter);
        picViewpager.setOnPageChangeListener(new PopPageChangeListener());
        picViewpager.setCurrentItem(picPosition);
        popTitleTv.setText(String.valueOf(picPosition + 1) + "/"
                + String.valueOf(popImageViews.size()));

    }

    private void deletePic() {
        picPosition = picViewpager.getCurrentItem();
        listString.remove(picPosition);
        picPathList.remove(picPosition);
        popImageViews.remove(picPosition);
        popAdapter.notifyDataSetChanged();
        picPosition = picPosition == 0 ? 0 : picPosition - 1;
        picViewpager.setCurrentItem(picPosition);
        if (picPathList.size() == 0) {
            onBackPressed();
        } else {
            popTitleTv.setText(String.valueOf(picPosition + 1) + "/"
                    + String.valueOf(popImageViews.size()));
        }
    }

    @Override
    public void initEvent() {
        backIv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        deleteTv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                deletePic();
            }
        });
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent();
        intent.putExtra("picList", picPathList);
        intent.putExtra("postionParent", postionParent);
        intent.putExtra("picPosition", picPosition);
        setResult(Activity.RESULT_OK, intent);
        finish();
        overridePendingTransition(R.anim.zoominother,
                R.anim.zoominother);
        if (delete) {
            RxBus.getRxBus().post("deleteAlbult", picPosition);
        }
    }

    private Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            popTitleTv.setText(String.valueOf(msg.arg1) + "/"
                    + String.valueOf(popImageViews.size()));
        }

    };

    class PopPageChangeListener implements OnPageChangeListener {

        @Override
        public void onPageScrollStateChanged(int arg0) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onPageScrolled(int arg0, float arg1, int arg2) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onPageSelected(int arg0) {
            // TODO Auto-generated method stub
            picPosition = arg0 + 1;
            Message msg = new Message();
            msg.arg1 = picPosition;
            handler.sendMessage(msg);
        }
    }

    class PicPagerAdapter extends PagerAdapter {

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return popImageViews.size();
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            // TODO Auto-generated method stub
            return arg0 == arg1;
        }

        @Override
        public Object instantiateItem(View container, final int position) {
            // TODO Auto-generated method stub
            ((ViewPager) container).addView(popImageViews.get(position));
            popImageViews.get(position).setOnClickListener(
                    new OnClickListener() {

                        @Override
                        public void onClick(View v) {
                            onBackPressed();
                            overridePendingTransition(R.anim.zoominother,
                                    R.anim.zoominother);

                        }
                    });
            if (0 == isLoad) {
                popImageViews.get(position).setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        uploadNumed = 0;
                        uploadNum = 0;
                        lengthPath = "";
                        imageView = popImageViews.get(position);
                        imageView.setDrawingCacheEnabled(true);
                        mPopupWindow = new BottomPopupWindow(ShowImagesPop.this, 0,
                                findViewById(R.id.shop_detail_pic_vp));
                        mPopupWindow.addItem("下载图片到手机", new MyAPopupWindow.onClickItemListener() {
                            @Override
                            public void clickItem(View v) {
                                Bitmap bitmap = popImageViews.get(position).getDrawingCache();
                                if (bitmap != null) {
                                    new SaveImageTask().execute(bitmap);
                                }
                            }
                        }, false);
                        if (isDelete) {
                            mPopupWindow.addItem(
                                    getResources().getString(
                                            R.string.shop_manage_list_del),
                                    new MyAPopupWindow.onClickItemListener() {

                                        @Override
                                        public void clickItem(View v) {
                                            deletePhoto(listString.get(position).getId());
                                        }
                                    }, false);
                        }
                        mPopupWindow.addItem(
                                getResources().getString(
                                        R.string.personal_info_choose_cancle),
                                new MyAPopupWindow.onClickItemListener() {

                                    @Override
                                    public void clickItem(View v) {
                                        mPopupWindow.dismiss();
                                    }
                                }, true);
                        mPopupWindow.show();
                        return true;
                    }
                });
            }

            return popImageViews.get(position);
        }

        @Override
        public void destroyItem(View container, int position, Object object) {
            //((ViewPager) container).removeView(popImageViews.get(position));
            View view = (View) object;
            ((ViewPager) container).removeView(view);
            view = null;
        }

        @Override
        public int getItemPosition(Object object) {
            return POSITION_NONE;
        }

        private class SaveImageTask extends AsyncTask<Bitmap, Void, String> {
            @Override
            protected String doInBackground(Bitmap... params) {
                String result = "";
                try {
                    String picPath = XmppFileHelper.getSDCardPath() + File.separator + CommonCache.APP_SAVE_DIR;
                    File dirFile = new File(picPath);
                    if (!dirFile.exists() || !dirFile.isDirectory()) {
                        dirFile.mkdirs();
                    }
                    File imageFile = new File(picPath, "download" + new Date().getTime() + ".jpg");
                    FileOutputStream outStream = null;
                    outStream = new FileOutputStream(imageFile);
                    Bitmap image = params[0];
                    image.compress(Bitmap.CompressFormat.JPEG, 100, outStream);
                    outStream.flush();
                    outStream.close();
                    result = imageFile.getAbsolutePath();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return result;
            }

            @Override
            protected void onPostExecute(String result) {
                imageView.setDrawingCacheEnabled(false);
                if (!TextUtils.isEmpty(result)) {
                    NormalToast.showToast(ShowImagesPop.this, "保存路径：" + result, Toast.LENGTH_LONG);
                }
            }
        }
    }

}
