package com.didi365.didi.client.appmode.index.index;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.didi365.didi.client.ClientApplication;
import com.didi365.didi.client.R;
import com.didi365.didi.client.appmode.index._adapters.ImageBrowserAdapter;
import com.didi365.didi.client.common.CommonCache;
import com.didi365.didi.client.common.CommonCheckPermission;
import com.didi365.didi.client.common.IsSelfPermissionCall;
import com.didi365.didi.client.common.views.NormalToast;
import com.ihengtu.xmpp.core.helper.XmppFileHelper;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;


public class ShowImageFromWebActivity extends Activity implements View.OnClickListener {
    private ViewPager vpImageBrowser;
    private TextView tvImageIndex;
    private Button btnSave;
    private LinearLayout upDown;
    private LinearLayout leftRight;

    private ImageBrowserAdapter adapter;
    private ArrayList<String> imgUrls;
    private String url;
    private int currentIndex;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_image_from_web);
        initView();
        initListener();
        initData();
    }

    private void initView() {
        vpImageBrowser = (ViewPager) findViewById(R.id.vp_image_browser);
        tvImageIndex = (TextView) findViewById(R.id.tv_image_index);
        btnSave = (Button) findViewById(R.id.btn_save);
        upDown = (LinearLayout) findViewById(R.id.up_down);
        leftRight = (LinearLayout) findViewById(R.id.left_right);
        if (!ClientApplication.isFitstPhoto) {
            upDown.setVisibility(View.VISIBLE);
            leftRight.setVisibility(View.VISIBLE);
        } else {
            upDown.setVisibility(View.GONE);
            leftRight.setVisibility(View.GONE);
        }
    }

    private void initData() {
        imgUrls = getIntent().getStringArrayListExtra("images");
        url = getIntent().getStringExtra("image");
        int position = imgUrls.indexOf(url);
        adapter = new ImageBrowserAdapter(this, imgUrls);
        vpImageBrowser.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        final int size = imgUrls.size();

        if (size > 1) {
            tvImageIndex.setVisibility(View.VISIBLE);
            tvImageIndex.setText((position + 1) + "/" + size);
        } else {
            tvImageIndex.setVisibility(View.GONE);
        }

        vpImageBrowser.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            @Override
            public void onPageSelected(int arg0) {
                currentIndex = arg0;
                int index = arg0 % size;
                tvImageIndex.setText((index + 1) + "/" + size);

            }

            @Override
            public void onPageScrolled(int arg0, float arg1, int arg2) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onPageScrollStateChanged(int arg0) {
                // TODO Auto-generated method stub
                upDown.setVisibility(View.GONE);
                leftRight.setVisibility(View.GONE);
            }
        });

        vpImageBrowser.setCurrentItem(position);
    }


    private void initListener() {
        btnSave.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_save:
                CommonCheckPermission.getPermission(ShowImageFromWebActivity.this).checkSDCardPermission(new IsSelfPermissionCall() {
                    @Override
                    public void call() {
//                        downloadImage();
                        if (adapter != null) {
                            adapter.getImage(adapter.pvShowImage);
                        }
                    }
                });

                break;
        }
    }

    /**
     * 开始下载图片
     */
    private void downloadImage() {
//        ImageLoaderUtils.downLoadImage(imgUrls.get(currentIndex), Environment.getExternalStorageDirectory().getAbsolutePath() + "/ImagesFromWebView", this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        CommonCheckPermission.Destory();
        ClientApplication.isFitstPhoto = true;
    }
}
