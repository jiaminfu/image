package com.didi365.didi.client.appmode.index._adapters;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v4.view.PagerAdapter;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;


import com.didi365.didi.client.R;
import com.didi365.didi.client.appmode.index.index.ShowImageFromWebActivity;
import com.didi365.didi.client.common.CommonCache;
import com.didi365.didi.client.common.imagebrowse.PhotoView;
import com.didi365.didi.client.common.imagebrowse.PhotoViewAttacher;
import com.didi365.didi.client.common.imgloader.ImageLoad;
import com.didi365.didi.client.common.views.NormalToast;
import com.didi365.didi.client.common.views.TouchImageView;
import com.ihengtu.xmpp.core.helper.XmppFileHelper;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class ImageBrowserAdapter extends PagerAdapter {

    private Activity context;
    private List<String> picUrls;
    public TouchImageView pvShowImage;
    private float xDistance, yDistance, xLast, yLast;
    boolean boo = false;

    public ImageBrowserAdapter(Activity context, ArrayList<String> picUrls) {
        this.context = context;
        this.picUrls = picUrls;
    }


    @Override
    public int getCount() {

        return picUrls.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public View instantiateItem(final ViewGroup container, int position) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_image_browser, null);
        pvShowImage = (TouchImageView) view.findViewById(R.id.pv_show_image);
        String picUrl = picUrls.get(position);
//		final  PhotoViewAttacher photoViewAttacher=new PhotoViewAttacher(pvShowImage);
//		photoViewAttacher.setScaleType(ImageView.ScaleType.FIT_CENTER);
//		photoViewAttacher.setMinimumScale(1F);
        ImageLoad.getAgainImage(context, picUrl, pvShowImage, R.drawable.smdd_place_680, R.drawable.smdd_place_680);
        pvShowImage.setDrawingCacheEnabled(true);
//		ImageLoaderUtils.displayScaleImage(context,pvShowImage,picUrl,photoViewAttacher);
        container.addView(view);


        pvShowImage.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        xDistance = yDistance = 0f;
                        xLast = yLast = 0f;
                        xLast = event.getX();
                        yLast = event.getY();
                        break;
                    case MotionEvent.ACTION_POINTER_DOWN:
                        break;
                    case MotionEvent.ACTION_POINTER_2_DOWN:
                        boo = true;
                        break;
                    case MotionEvent.ACTION_POINTER_UP:
                        boo = false;
                        break;
                    case MotionEvent.ACTION_MOVE:
                        if (!boo && event.getPointerCount() == 1) {
                            final float curX = event.getX();
                            final float curY = event.getY();
                            xDistance += Math.abs(curX - xLast);
                            yDistance += Math.abs(curY - yLast);
                            xLast = curX;
                            yLast = curY;
                            if (xDistance > yDistance) {
                                return false;
                            }
                            if (yDistance - 200 > xDistance) {
                                ((ShowImageFromWebActivity) context).finish();
                            }
                        }
                        break;
                }
                return false;
            }
        });
        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    public void getImage(ImageView imageView) {
        Bitmap bitmap = imageView.getDrawingCache();
        if (bitmap != null) {
            new SaveImageTask(imageView).execute(bitmap);
        }
    }

    private class SaveImageTask extends AsyncTask<Bitmap, Void, String> {
        private ImageView imageView;
        private File dirFile;

        public SaveImageTask(ImageView imageView) {
            this.imageView = imageView;
        }

        @Override
        protected String doInBackground(Bitmap... params) {
            String result = "";
            try {
                String picPath = XmppFileHelper.getSDCardPath() + File.separator + CommonCache.APP_SAVE_DIR;
                dirFile = new File(picPath);
                if (!dirFile.exists() || !dirFile.isDirectory()) {
                    dirFile.mkdirs();
                }
                File imageFile = new File(picPath, "download" + new Date().getTime() + ".jpg");
                FileOutputStream outStream = null;
                outStream = new FileOutputStream(imageFile);
                Bitmap image = params[0];
                image.compress(Bitmap.CompressFormat.JPEG, 100, outStream);
                outStream.flush();
                outStream.close();
                result = imageFile.getAbsolutePath();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            imageView.setDrawingCacheEnabled(false);
            if (!TextUtils.isEmpty(result)) {
                NormalToast.showToast(context, "保存路径：" + result, Toast.LENGTH_LONG);
            }
            //更新相册
            Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            Uri uri = Uri.fromFile(dirFile);
            intent.setData(uri);
            context.sendBroadcast(intent);
        }
    }

}